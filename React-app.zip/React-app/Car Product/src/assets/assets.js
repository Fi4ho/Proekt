import product_1 from './product_1.webp'
import product_2 from './product_2.webp'
import product_3 from './product_3.webp'
import product_4 from './product_4.webp'
import product_5 from './product_5.webp'
import product_6 from './product_6.webp'

import tyres_1 from './tyres_1.webp'
import tyres_2 from './tyres_2.webp'
import tyres_3 from './tyres_3.webp'
import tyres_4 from './tyres_4.webp'
import tyres_5 from './tyres_5.webp'

import brake_1 from './brake_1.webp'
import brake_2 from './brake_2.webp'
import brake_3 from './brake_3.webp'
import brake_4 from './brake_4.webp'
import brake_5 from './brake_5.webp'

import engine_1 from './engine_1.webp'
import engine_2 from './engine_2.webp'
import engine_3 from './engine_3.webp'
import engine_4 from './engine_4.webp'
import engine_5 from './engine_5.webp'


import battery_1 from './battery_1.webp'
import battery_2 from './battery_2.webp'
import battery_3 from './battery_3.webp'
import battery_4 from './battery_4.webp'
import battery_5 from './battery_5.webp'

import aircondition_1 from './aircondition_1.webp'
import aircondition_2 from './aircondition_2.webp'
import aircondition_3 from './aircondition_3.webp'
import aircondition_4 from './aircondition_4.webp'
import aircondition_5 from './aircondition_5.webp'

import lights_1 from './lights_1.webp'
import lights_2 from './lights_2.webp'
import lights_3 from './lights_3.webp'
import lights_4 from './lights_4.webp'
import lights_5 from './lights_5.webp'

import add_icon_white from './add_icon_white.webp'
import red_minus_icon from './red_minus_icon.webp'
import green_plus_icon from './green_plus_icon.webp'
import logo_image from './logo_image.webp'
import googleplay_store from './googleplay_store.webp'
import appstore_icon from './appstore_icon.webp'
import cross_icon from './cross_icon.webp'
import parcel_icon from './parcel_icon.webp'


export const assets = {
    add_icon_white,
    red_minus_icon,
    green_plus_icon,
    logo_image,
    googleplay_store,
    appstore_icon,
    cross_icon,
    parcel_icon,
   

}

export const product_list = [
    {
        _id: "1",
        name:"Summer",
        image: tyres_1,
        price: 54,
        descriptions: "Summer Tyres",
        category: "Summer"
    },
    {
        _id: "2",
        name:"Winter",
        image: tyres_2,
        price: 50,
        descriptions:"At temperatures below 7c,certified winter tyres with the M+S or 3PMSF markings are safer and have a shorter stopping distance than summer tyres or wet,slowly on icy roads",
        category: "Winter"
    },
    {
        _id: "3",
        name:"All-season",
        image: tyres_3,
        price: 45,
        descriptions:"All-season and all-weather tyres offer excellent grip in wet and wintery conditions,while their softer rubber compound can also improve your vehicle's roand handling and comfort in the summer month",
        category: "All Season"

    },
    {
        _id: "4",
        name:"Sport",
        image: tyres_4,
        price: 48,
        descriptions: "Sport tyres are suitable for high-performance vehicles and drivers who want to extract as much performance from their cars a possible",
        category: "Sport"
    },
    {
        _id: "5",
        name:"SUV",
        image: tyres_5,
        price: 60,
        descriptions: "Suv stands for sport utility vehicle.Suv are generally high,spacion and versatile.The suv has evolved over time from military off-road vehicle to are of the most popular car categories available",
        category: "SUV" 
    },
    {
        _id: "6",
        name:"Standard",
        image: brake_1,
        price: 36.50,
        descriptions:"A standard brake disc also known as a rotor, is a critical components of a vehicle breaking system",
        category: "Standard"
    },
    {
        _id: "7",
        name:"Vented",
        image: brake_2,
        price: 45.70,
        descriptions:"Vented brake discs are designed to enhance braking performance bt incorporating interral cooling channels",
        category: "Vented"
    },
    {
        _id: "8",
        name: "Carbon",
        image: brake_3,
        price: 54.99,
        descriptions: "Carbon-ceramic brake discs are high-performance braking component designed for exceptional durability and heat resistance",
        category: "Carbon"
    },
    {
        _id: "9",
        name: "Slotted",
        image: brake_4,
        price: 45.99,
        descriptions: "Slotted brake discs are designed to enhance braking performance through strategically placed grooves are slots on their surface",
        category: "Slotted"
    },
    {
        _id: "10",
        name: "Drills+Slotted",
        image: brake_5,
        price: 59.99,
        descriptions: "Drill holes and slots in rotors can both improve vraking,but under diffrent braking scenarios",
        category: "Drills+Slotted"
    },
    {
        _id: "11",
        name: "Diesel",
        image: engine_1,
        price: 255.99,
        descriptions: "The diesel engine named after the german enginner Rudolf Diesel, is an internal combustion engine is which of the fuel is caused by the elevated temperatures of the air in the cyllinder due to mechanical compression",
        category: "Diesel"
    },
    {
        _id: "12",
        name: "Benzin",
        image: engine_2,
        price: 350,
        descriptions: "A petrol engine is an internal combustion engine design to run on petrol.Petrol engines can often be adopted to also run of fuels such as liquefied petroleum gas and ethanol blends",
        category: "Benzin"
    },
    {
        _id: "13",
        name: "Hybrid",
        image: engine_3,
        price: 455.99,
        descriptions: "Hybrid electric vehicles are powered by an internal combustion engine and one or more electric motors,which uses energy stored in batteries",
        category: "Hybrid"
    },
    {
        _id: "14",
        name: "Electric",
        image: engine_4,
        price: 200,
        descriptions: "Moreover,the operating temperature of an electric engine is signaficunty lower compared to an internal combustion engine",
        category: "Electric"
    },
    {
        _id: "15",
        name: "Rotary",
        image: engine_5,
        price: 150,
        descriptions: "A rotating detonation engine uses a form a pressure gain combustion where one or more detonations continuusly travel around an anrular channel",
        category: "Rotary"
    },
    {
        _id: "16",
        name: "Lead battery",
        image: battery_1,
        price: 35,
        descriptions: "The lead-acid battery is a type of rechargeable battery first invented in 1859 by french physicist Gaston Plante,Liquid-acid batteries have relatively low energy destiny",
        category: "Lead battery"
    },
    {
        id: "17",
        name: "Lithium-ion",
        image: battery_2,
        price: 65,
        descriptions: "Lithium-ion batteries are rechargeable batteries that use lithium ions as the prismary components of their electro chemistry",
        category: "Lithium-ion"
    },
    {
        _id: "18",
        name: "Gel battery",
        image: battery_3,
        price: 59.55,
        descriptions: "While gel batteries have good cycle life and deep discharge capabillifies they may have slightly lower energy destiny compared to lithium-ion batteries",
        category: "Gel battery"
    },
    {
        _id: "19",
        name: "Solar",
        image: battery_4,
        price: 56.55,
        descriptions: "Solar batteries are energy storage systems specifically designed to store electricity generated from solar panel",
        category: "Solar",
    },
    {
        _id: "20",
        name: "Sodium",
        image: battery_5,
        price: 59.50,
        descriptions: "Sodium battery specifically sodium-ion batteries are an emerging elternative to lithium-ion batteries",
        category: "Sodium"
    },
    {
        _id: "21",
        name: "Water",
        image: aircondition_1,
        price: 50.99,
        descriptions: "Water air conditioning often referred to as evaporative cooling or swamp cooling,is a method of cooling air by utiling the evaporation of water",
        category: "Water"
    },
    {
        _id: "22",
        name: "Oil",
        image: aircondition_2,
        price: 45,
        descriptions: "Oil air conditioning systems typically refer to the use of oil-based refrigerants in HVAC(heating,ventilation and air condutioning).",
        category: "Oil"
    },
    {
        _id: "23",
        name: "Hybrid",
        image: aircondition_3,
        price: 40.99,
        descriptions: "Hybrid air conditioning system combine multiple cooling methods to optimize efficiency,comfort, and energy use",
        category: "Hybrid"
    },
    {
        _id: "24",
        name: "Liquid",
        image: aircondition_4,
        price: 35,
        descriptions: "Liquid air conditioning often reffered to as liquid cooling or liquid-to-air cooling systems utilites a liquid cooling to transfer heat away from a space",
        category: "Liquid"
    },
    {
        _id: "25",
        name: "Air-conditioning",
        image: aircondition_5,
        price: 57,
        descriptions: "Air-to_air conditioning systems are a type of system that uses air as both the heat transfer medium and the cooling medium",
        category: "Air-conditioning"
    },
    {
        _id: "26",
        name: "DayLight",
        image: lights_1,
        price: 10.99,
        descriptions: "Light refers to the concept of daylighting which involves using natural light to iluminate indoor spaces",
        category: "DayLight" 
    },
    {
        _id: "27",
        name: "Additional",
        image: lights_2,
        price: 7.99,
        descriptions: "Using additional light effectively can greatly enhance the comfort and functionality or any space",
        category: "Additional"
    },
    {
        _id: "28",
        name: "Led",
        image: lights_3,
        price: 5.99,
        descriptions: "Led light are i higly efficient and versatile lighting option.Led Lightinhg is an enviromentally friendly choice",
        category: "Led"
    },
    {
        _id: "29",
        name: "Fog",
        image: lights_4,
        price: 10,
        descriptions: "Fog lights are specialized vehicle lights designed to iluminate the road directly in front of a vehicle in foggy or low-visibility conditions",
        category: "Fog"
    },
    {
        _id: "30",
        name: "Back Light",
        image: lights_5,
        price: 12,
        descriptions: "The brake light wiring system in most cars is not overly complex. At one end, you have the lights themselves: bulbs in sockets connected to a wiring harness. At the other end is the brake switch, where the pedal presses down and creates contact that completes the circuit. The system draws power from the car's battery",
        category: "Back Light"
    },
]


export const menu_list = [
    {
      menu_name: "Tyres",
      menu_image: product_1
    },
    {
        menu_name: "Brake Discs",
        menu_image: product_2
    },
    {
        menu_name: "Engines",
        menu_image: product_3
    },
    {
        menu_name: "Batteries",
        menu_image: product_4
    },
    {
        menu_name: "Air Conditionings",
        menu_image: product_5
    },
    {
        menu_name: "Lights",
        menu_image: product_6
    },
]

