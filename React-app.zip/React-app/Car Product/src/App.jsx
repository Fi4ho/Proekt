import React, { useState } from 'react'
import Navbar from './components/Navbar/Navbar'
import { Route, Routes, Router } from 'react-router-dom' 
import Home from './pages/Home/Home'
import Cart from './pages/Cart/Cart'
import PlaceOrder from './pages/PlaceOrder/PlaceOrder'
import Footer from './components/Footer/Footer'
import LoginPopup from './components/LoginPopup/LoginPopup'
import PaymentForm from './components/Payment/PaymentForm'
import MyOrders from './components/MyOrders/MyOrders'

import { loadStripe } from '@stripe/stripe-js';




const stripePromise = loadStripe("pk_test_51QAfIqEHrijzi69SjLeOYErGEZ2I1rgC0isXJiGQNnOVEQx5233v4mahUEyevq4JDCIYUrKes02KkXyeikW0YiaV003qP3f37M");



const App = () => {

const [showLogin,setShowLogin] = useState(false)

  return (
    
    <>
    {showLogin? <LoginPopup setShowLogin={setShowLogin}/>:<></>}
    <div className='app'>


  

      <Navbar setShowLogin={setShowLogin}/>
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/cart' element={<Cart/>} />
        <Route path='/order' element={<PlaceOrder/>} />
        <Route path='/myorders' element={<MyOrders />}/>
        <Route path='/payment' element={<PaymentForm/>}/>
      </Routes>
    </div>
    <Footer/>
    </>
  )
};

export default App
