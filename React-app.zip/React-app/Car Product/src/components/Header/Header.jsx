import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
      <div className="header-contents">
        <h2>Order your favourite car components</h2>
        <p>Looking to upgrade your ride or enhance performance? Our premium car components are designed to take your vehicle to the next level! From high-performance brakes and suspension kits to sleek exhaust systems and cutting-edge electronics, we offer a wide range of top-quality parts that fit most makes and models. Each component is rigorously tested for durability and efficiency, ensuring that you get the best performance and reliability. Plus, with competitive pricing and expert customer support, we make it easy for you to find exactly what you need. Don’t settle for less—elevate your driving experience today!</p>
        <button>View Products</button>
      </div>
    </div>
  )
}

export default Header
