import React from 'react'
import './Footer.css'
import { assets } from '../../assets/assets'

const Footer = () => {
  return (
    <div className='footer' id='footer'>
      <div className="footer-content">
        <div className="footer-content-left">
              <img src={assets.logo_image} alt="" />
              <p>This is our first website</p>
        </div>
        
        <div className="footer-content-center">
        <h2>Company</h2>
        <ul>
            <li>Home</li>
            <li>About Us</li>
            <li>Delivery</li>
            <li>Privacy policy</li>
        </ul>
      </div>
      <div className="footer-content-right">
         <h2>GET IN TOUCH</h2>
         <ul>
            <li>+1-212-456-9856</li>
            <li>contact@company.com</li>
         </ul>
      </div>
      
    </div>
       
    <p className="footer-copyright">Copyright 2024 company.com -All Right Reserverd</p>
    </div>
  )
}

export default Footer
